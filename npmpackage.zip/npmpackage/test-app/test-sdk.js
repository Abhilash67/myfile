// This script sets up the mock Auth0 client and runs tests on the SDK

import mockAuth0 from './src/mocks/auth0-mock';

// Attach the mock to the window object
window.auth0 = mockAuth0;

// Import our application which uses the SDK
import('./src/index').then(() => {
  console.log('Test app initialized with Auth0 mock');
  
  // You can add automated tests here
  // For example:
  /*
  const runAutomatedTests = async () => {
    const { useAuth } = await import('./dist/index.esm.js');
    // Test SDK functions
  };
  
  runAutomatedTests().catch(console.error);
  */
});