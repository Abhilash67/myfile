import React from 'react';
import { AuthContextProvider, useAuth } from '../dist/index.esm.js';
import { AuthContextProvider, useAuth } from 'E:/npmpackage/dist/index.esm.js';

// Login button component
const LoginButton = () => {
  const { login, isLoading } = useAuth();
  
  const handleLogin = () => {
    login();
  };
  
  return (
    <button onClick={handleLogin} disabled={isLoading}>
      {isLoading ? 'Loading...' : 'Log In'}
    </button>
  );
};

// Login with popup button component
const LoginWithPopupButton = () => {
  const { loginWithPopup, isLoading } = useAuth();
  
  const handleLogin = async () => {
    try {
      const user = await loginWithPopup();
      console.log('Logged in user:', user);
    } catch (error) {
      console.error('Login error:', error);
    }
  };
  
  return (
    <button onClick={handleLogin} disabled={isLoading}>
      {isLoading ? 'Loading...' : 'Log In with Popup'}
    </button>
  );
};

// Logout button component
const LogoutButton = () => {
  const { logout, isLoading } = useAuth();
  
  const handleLogout = () => {
    logout();
  };
  
  return (
    <button onClick={handleLogout} disabled={isLoading}>
      {isLoading ? 'Loading...' : 'Log Out'}
    </button>
  );
};

// User profile component
const UserProfile = () => {
  const { user, isAuthenticated, isLoading, getAccessToken } = useAuth();
  
  const handleGetToken = async () => {
    try {
      const token = await getAccessToken();
      console.log('Access token:', token);
      alert(`Token: ${token.slice(0, 20)}...`);
    } catch (error) {
      console.error('Token error:', error);
    }
  };
  
  if (isLoading) {
    return <div>Loading user profile...</div>;
  }
  
  if (!isAuthenticated) {
    return <div>Please log in to view your profile</div>;
  }
  
  return (
    <div>
      <h2>User Profile</h2>
      <p><strong>Name:</strong> {user.name}</p>
      <p><strong>Email:</strong> {user.email}</p>
      <button onClick={handleGetToken}>Get Access Token</button>
      <pre>{JSON.stringify(user, null, 2)}</pre>
    </div>
  );
};

// Protected component
const ProtectedContent = () => {
  return (
    <div>
      <h2>Protected Content</h2>
      <p>This content is only visible to authenticated users.</p>
    </div>
  );
};

// Auth status component
const AuthStatus = () => {
  const { isAuthenticated, isLoading, error } = useAuth();
  
  if (isLoading) {
    return <div>Checking authentication status...</div>;
  }
  
  if (error) {
    return <div>Error: {error.message}</div>;
  }
  
  return (
    <div>
      <p>Authentication Status: {isAuthenticated ? 'Authenticated' : 'Not Authenticated'}</p>
    </div>
  );
};

// Main App component
const App = () => {
  // Auth0 configuration for testing
  const auth0Config = {
    domain: 'dev-vfzstbs1dxkuagab.us.auth0.com', // Replace with your Auth0 domain
    clientId: 'CP6smmR7f8NVud69LolHjy8YWSPUZ7g0', // Replace with your Auth0 client ID
    redirectUri: window.location.origin,
    audience: 'https://api.example.com'
  };
  
  const handleLogin = (user) => {
    console.log('User logged in:', user);
  };
  
  const handleLogout = () => {
    console.log('User logged out');
  };
  
  const handleError = (error) => {
    console.error('Auth error:', error);
  };
  
  return (
    <AuthContextProvider 
      providerType="auth0" 
      providerConfig={auth0Config}
      onLogin={handleLogin}
      onLogout={handleLogout}
      onError={handleError}
    >
      <div className="App">
        <header className="App-header">
          <h1>Auth SDK Test App</h1>
          <AuthStatus />
          
          <div style={{ margin: '20px 0', display: 'flex', gap: '10px' }}>
            <LoginButton />
            <LoginWithPopupButton />
            <LogoutButton />
          </div>
          
          <UserProfile />
          
          <div style={{ marginTop: '20px', padding: '10px', border: '1px solid #ddd' }}>
            <ProtectedContent />
          </div>
        </header>
      </div>
    </AuthContextProvider>
  );
};

export default App;