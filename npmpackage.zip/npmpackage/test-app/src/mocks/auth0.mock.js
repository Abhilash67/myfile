// Mock Auth0 implementation for testing
// This will be attached to the window object to simulate the Auth0 SDK

const mockUser = {
    sub: 'auth0|123456789',
    name: 'Test User',
    email: 'test@example.com',
    picture: 'https://via.placeholder.com/150',
    updated_at: new Date().toISOString(),
    email_verified: true
  };
  
  const mockAuth0 = {
    createAuth0Client: async (config) => {
      console.log('Auth0 config:', config);
      
      // Simulate a delay for async operations
      const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));
      
      // Mock client implementation
      return {
        // Track authentication state
        _authenticated: false,
        
        // Check if user is authenticated
        isAuthenticated: async () => {
          await delay(500); // Simulate network delay
          return mockAuth0.client._authenticated;
        },
        
        // Get user details
        getUser: async () => {
          await delay(300);
          if (!mockAuth0.client._authenticated) {
            return null;
          }
          return mockUser;
        },
        
        // Handle redirect callback
        handleRedirectCallback: async () => {
          await delay(500);
          mockAuth0.client._authenticated = true;
          return {
            appState: {}
          };
        },
        
        // Login with redirect
        loginWithRedirect: async (options) => {
          console.log('Login with redirect, options:', options);
          await delay(500);
          
          // In a real scenario, this would redirect to Auth0
          // For our mock, we'll simulate the redirect by changing the URL
          const redirectUrl = `${window.location.origin}?code=mock_code&state=mock_state`;
          window.history.pushState({}, document.title, redirectUrl);
          
          // Manually trigger our callback since there's no real redirect
          await mockAuth0.client.handleRedirectCallback();
          
          return true;
        },
        
        // Login with popup
        loginWithPopup: async (options) => {
          console.log('Login with popup, options:', options);
          await delay(1000);
          
          // Simulate popup authentication (without actually showing a popup)
          mockAuth0.client._authenticated = true;
          
          return true;
        },
        
        // Logout
        logout: async (options) => {
          console.log('Logout, options:', options);
          await delay(500);
          
          mockAuth0.client._authenticated = false;
          
          // In a real scenario, this may redirect to Auth0 logout page
          // For our mock, we'll just reset the URL
          window.history.replaceState({}, document.title, window.location.pathname);
          
          return true;
        },
        
        // Get access token silently
        getTokenSilently: async () => {
          await delay(500);
          
          if (!mockAuth0.client._authenticated) {
            throw new Error('Not authenticated');
          }
          
          // Generate a mock JWT token
          return 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IlRlc3QgVXNlciIsImlhdCI6MTUxNjIzOTAyMn0.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c';
        }
      };
    }
  };
  
  // Store the mock client so it can be accessed
  mockAuth0.client = null;
  
  export default mockAuth0;