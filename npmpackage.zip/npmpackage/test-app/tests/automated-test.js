// Automated test script for the Auth SDK
// This can be run in a Node.js environment with appropriate mocks

const { AuthProvider } = require('../dist/index.esm.js');

// Implement a simple test framework
const test = async (name, testFn) => {
  try {
    console.log(`Running test: ${name}`);
    await testFn();
    console.log(`✅ Test passed: ${name}`);
  } catch (error) {
    console.error(`❌ Test failed: ${name}`);
    console.error(error);
    process.exitCode = 1;
  }
};

// Mock the Auth0 client for Node.js environment
global.window = {
  location: {
    origin: 'http://localhost:3000',
    pathname: '/'
  },
  history: {
    replaceState: () => {},
    pushState: () => {}
  },
  auth0: {
    createAuth0Client: async () => ({
      isAuthenticated: async () => true,
      getUser: async () => ({ name: 'Test User', email: 'test@example.com' }),
      handleRedirectCallback: async () => ({ appState: {} }),
      loginWithRedirect: async () => true,
      loginWithPopup: async () => true,
      logout: async () => true,
      getTokenSilently: async () => 'test-token'
    })
  }
};

global.document = {
  title: 'Test Page',
  body: {
    appendChild: () => {}
  },
  createElement: () => ({
    src: '',
    async: false,
    onload: null,
    onerror: null
  }),
  querySelector: () => null
};

// Run the tests
const runTests = async () => {
  // Test AuthProvider initialization
  await test('AuthProvider initialization', async () => {
    const provider = new AuthProvider({
      providerType: 'auth0',
      providerConfig: {
        domain: 'test.auth0.com',
        clientId: 'test-client-id'
      }
    });
    
    if (!provider.provider) {
      throw new Error('Provider not initialized');
    }
    
    await provider.initialize();
  });
  
  // Test AuthProvider login
  await test('AuthProvider login', async () => {
    const provider = new AuthProvider({
      providerType: 'auth0',
      providerConfig: {
        domain: 'test.auth0.com',
        clientId: 'test-client-id'
      }
    });
    
    await provider.initialize();
    
    let eventEmitted = false;
    provider.on('authenticated', () => {
      eventEmitted = true;
    });
    
    await provider.login();
    
    if (!eventEmitted) {
      throw new Error('Authentication event not emitted');
    }
  });
  
  // Test AuthProvider getAccessToken
  await test('AuthProvider getAccessToken', async () => {
    const provider = new AuthProvider({
      providerType: 'auth0',
      providerConfig: {
        domain: 'test.auth0.com',
        clientId: 'test-client-id'
      }
    });
    
    await provider.initialize();
    const token = await provider.getAccessToken();
    
    if (token !== 'test-token') {
      throw new Error('Invalid token returned');
    }
  });
  
  // Test provider event system
  await test('Provider event system', async () => {
    const provider = new AuthProvider({
      providerType: 'auth0',
      providerConfig: {
        domain: 'test.auth0.com',
        clientId: 'test-client-id'
      }
    });
    
    let eventCount = 0;
    const eventHandler = () => {
      eventCount++;
    };
    
    provider.on('test-event', eventHandler);
    provider._dispatchEvent('test-event', {});
    
    if (eventCount !== 1) {
      throw new Error('Event not dispatched');
    }
    
    provider.off('test-event', eventHandler);
    provider._dispatchEvent('test-event', {});
    
    if (eventCount !== 1) {
      throw new Error('Event handler not removed');
    }
  });
  
  console.log('All tests completed!');
};

runTests().catch(error => {
  console.error('Test suite failed:', error);
  process.exitCode = 1;
});