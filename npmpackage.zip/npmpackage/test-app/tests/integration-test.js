// Integration test script
// This simulates a complete auth flow in a browser-like environment

import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { AuthContextProvider, useAuth } from '../dist/index.esm.js';

// Mock for Auth0 client
window.auth0 = {
  createAuth0Client: jest.fn().mockImplementation(() => {
    return Promise.resolve({
      isAuthenticated: jest.fn().mockResolvedValue(false),
      getUser: jest.fn().mockResolvedValue({
        name: 'Test User',
        email: 'test@example.com'
      }),
      handleRedirectCallback: jest.fn().mockResolvedValue({ appState: {} }),
      loginWithRedirect: jest.fn().mockResolvedValue(true),
      loginWithPopup: jest.fn().mockImplementation(() => {
        // Simulate authentication state change
        this.isAuthenticated.mockResolvedValue(true);
        return Promise.resolve(true);
      }),
      logout: jest.fn().mockResolvedValue(true),
      getTokenSilently: jest.fn().mockResolvedValue('mock-token-123')
    });
  })
};

// Test Component using our hooks
const TestComponent = () => {
  const { 
    isAuthenticated, 
    isLoading, 
    user, 
    error, 
    login, 
    loginWithPopup, 
    logout, 
    getAccessToken 
  } = useAuth();
  
  return (
    <div>
      <div data-testid="loading-status">
        {isLoading ? 'Loading' : 'Not Loading'}
      </div>
      
      <div data-testid="auth-status">
        {isAuthenticated ? 'Authenticated' : 'Not Authenticated'}
      </div>
      
      {user && (
        <div data-testid="user-info">
          {user.name} ({user.email})
        </div>
      )}
      
      {error && (
        <div data-testid="error-info">
          {error.message}
        </div>
      )}
      
      <button data-testid="login-btn" onClick={() => login()}>
        Log In
      </button>
      
      <button data-testid="popup-btn" onClick={() => loginWithPopup()}>
        Log In with Popup
      </button>
      
      <button data-testid="logout-btn" onClick={() => logout()}>
        Log Out
      </button>
      
      <button 
        data-testid="token-btn" 
        onClick={async () => {
          try {
            const token = await getAccessToken();
            document.getElementById('token-output').textContent = token;
          } catch (err) {
            console.error(err);
          }
        }}
      >
        Get Token
      </button>
      
      <div id="token-output" data-testid="token-output"></div>
    </div>
  );
};

// Wrapper component for tests
const TestWrapper = ({ children }) => {
  const config = {
    domain: 'test.auth0.com',
    clientId: 'test-client-id',
    redirectUri: window.location.origin
  };
  
  return (
    <AuthContextProvider 
      providerType="auth0" 
      providerConfig={config}
      onLogin={(user) => console.log('Login callback', user)}
      onLogout={() => console.log('Logout callback')}
      onError={(err) => console.error('Error callback', err)}
    >
      {children}
    </AuthContextProvider>
  );
};

// Tests
describe('Auth SDK Integration Tests', () => {
  test('Initial render shows loading state', async () => {
    render(
      <TestWrapper>
        <TestComponent />
      </TestWrapper>
    );
    
    expect(screen.getByTestId('loading-status').textContent).toBe('Loading');
    
    await waitFor(() => {
      expect(screen.getByTestId('loading-status').textContent).toBe('Not Loading');
    });
  });
  
  test('Login with popup flow', async () => {
    render(
      <TestWrapper>
        <TestComponent />
      </TestWrapper>
    );
    
    // Wait for initialization
    await waitFor(() => {
      expect(screen.getByTestId('loading-status').textContent).toBe('Not Loading');
    });
    
    // Initial state should be unauthenticated
    expect(screen.getByTestId('auth-status').textContent).toBe('Not Authenticated');
    
    // Click login button
    fireEvent.click(screen.getByTestId('popup-btn'));
    
    // Should show loading state
    expect(screen.getByTestId('loading-status').textContent).toBe('Loading');
    
    // Wait for auth to complete
    await waitFor(() => {
      expect(screen.getByTestId('loading-status').textContent).toBe('Not Loading');
      expect(screen.getByTestId('auth-status').textContent).toBe('Authenticated');
    });
    
    // User info should be displayed
    expect(screen.getByTestId('user-info').textContent).toContain('Test User');
  });
  
  test('Access token retrieval', async () => {
    render(
      <TestWrapper>
        <TestComponent />
      </TestWrapper>
    );
    
    // Wait for initialization and simulate authenticated state
    await waitFor(() => {
      expect(screen.getByTestId('loading-status').textContent).toBe('Not Loading');
    });
    
    // Get token
    fireEvent.click(screen.getByTestId('token-btn'));
    
    // Check token output
    await waitFor(() => {
      expect(screen.getByTestId('token-output').textContent).toBe('mock-token-123');
    });
  });
  
  test('Logout flow', async () => {
    render(
      <TestWrapper>
        <TestComponent />
      </TestWrapper>
    );
    
    // Wait for initialization and simulate authenticated state
    await waitFor(() => {
      expect(screen.getByTestId('loading-status').textContent).toBe('Not Loading');
    });
    
    // First login
    fireEvent.click(screen.getByTestId('popup-btn'));
    
    await waitFor(() => {
      expect(screen.getByTestId('auth-status').textContent).toBe('Authenticated');
    });
    
    // Then logout
    fireEvent.click(screen.getByTestId('logout-btn'));
    
    // Should show loading state
    expect(screen.getByTestId('loading-status').textContent).toBe('Loading');
    
    // Wait for logout to complete
    await waitFor(() => {
      expect(screen.getByTestId('auth-status').textContent).toBe('Not Authenticated');
    });
  });
});