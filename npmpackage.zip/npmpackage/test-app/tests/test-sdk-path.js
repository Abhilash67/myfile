// CommonJS version (for Node.js compatibility)
const fs = require('fs');
const path = require('path');

// Check if the SDK file exists
const sdkPath = path.resolve('E:\\npmpackage\\dist\\index.esm.js');

try {
  // Check if the file exists
  if (fs.existsSync(sdkPath)) {
    console.log('✅ SDK file found at the specified path:', sdkPath);
    
    // For ESM modules, we can't directly require them in CommonJS
    // Instead, we'll check the file content to verify it's a valid JS file
    const fileContent = fs.readFileSync(sdkPath, 'utf8');
    
    console.log('✅ Successfully read the SDK file');
    
    // Check for expected export patterns in the content
    const hasExports = [
      'AuthProvider',
      'Auth0Provider',
      'AuthContextProvider',
      'useAuth',
      'withAuth'
    ].every(exportName => 
      fileContent.includes(`export { ${exportName}`) || 
      fileContent.includes(`export function ${exportName}`) ||
      fileContent.includes(`export const ${exportName}`) ||
      fileContent.includes(`export class ${exportName}`)
    );
    
    if (hasExports) {
      console.log('✅ SDK file appears to contain the expected exports');
    } else {
      console.warn('⚠️ Some expected exports might be missing from the SDK file');
    }
    
    console.log('\nTo fully test the SDK, run the React test application with:');
    console.log('npm start');
    
  } else {
    console.error('❌ SDK file not found at path:', sdkPath);
    console.log('Please check that the path is correct and the file exists.');
    console.log('Expected full path:', path.resolve(sdkPath));
    
    // Try to find the file in nearby locations
    const baseDir = path.resolve('E:\\npmpackage');
    if (fs.existsSync(baseDir)) {
      console.log('\nSearching for index.esm.js in', baseDir);
      
      let foundFiles = [];
      function findFile(directory, fileName) {
        const files = fs.readdirSync(directory);
        
        for (const file of files) {
          const fullPath = path.join(directory, file);
          const stat = fs.statSync(fullPath);
          
          if (stat.isDirectory()) {
            findFile(fullPath, fileName);
          } else if (file === fileName) {
            foundFiles.push(fullPath);
          }
        }
      }
      
      try {
        findFile(baseDir, 'index.esm.js');
        
        if (foundFiles.length > 0) {
          console.log('Found potential SDK files:');
          foundFiles.forEach(file => console.log('-', file));
        } else {
          console.log('No index.esm.js files found in the directory tree.');
        }
      } catch (err) {
        console.error('Error while searching for files:', err.message);
      }
    }
  }
} catch (error) {
  console.error('❌ Error while testing SDK path:', error.message);
}