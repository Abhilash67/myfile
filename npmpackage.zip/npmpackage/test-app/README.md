# Auth SDK Test Application

This application is designed to test the authentication SDK located at `E:\npmpackage\dist\index.esm.js`.

## Setup Instructions

1. Make sure your SDK is built and available at the correct path:
   ```
   E:\npmpackage\dist\index.esm.js
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Create a symbolic link to your SDK (if needed):
   ```bash
   # On Windows
   mklink /D dist E:\npmpackage\dist
   
   # On Unix/Mac
   ln -s /path/to/E:/npmpackage/dist dist
   ```

4. Start the application:
   ```bash
   npm start
   ```

## Testing the SDK

The application provides a UI to test the following functionality:

- Authentication initialization
- Login (with redirect)
- Login with popup
- Logout
- Getting user profile information
- Getting access tokens
- Authentication status checks

## Authentication Flow

1. The app initializes the `AuthContextProvider` with Auth0 configuration
2. Try the "Log In" or "Log In with Popup" buttons
3. After successful authentication, the user profile will be displayed
4. You can get the access token or log out

## Testing with Mock

The app includes a mock implementation of the Auth0 client for testing without an actual Auth0 account. The mock simulates:

- Authentication flow
- User profile data
- Token issuance
- Login and logout operations

## Debugging

If you encounter issues:

1. Check browser console for error messages
2. Verify the SDK path is correct
3. Ensure all imports are correctly specified
4. Check network requests for any API calls

## Notes for Real Authentication

To use real Auth0 authentication:

1. Replace the Auth0 domain and client ID in `App.js` with your actual Auth0 credentials
2. Remove or disable the Auth0 mock in `test-sdk.js`
3. Ensure your Auth0 application is configured with the correct callback URLs