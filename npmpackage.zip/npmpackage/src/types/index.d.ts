import React from 'react';

/**
 * Auth provider types
 */
export type ProviderType = 'auth0' | string;

/**
 * Auth provider configuration
 */
export interface ProviderConfig {
  domain: string;
  clientId: string;
  audience?: string;
  redirectUri?: string;
  scope?: string[] | string;
  [key: string]: any;
}

/**
 * Auth context value
 */
export interface AuthContextValue {
  isAuthenticated: boolean;
  isLoading: boolean;
  user: any | null;
  error: Error | null;
  login: (options?: any) => Promise<void>;
  loginWithPopup: (options?: any) => Promise<any>;
  logout: (options?: any) => Promise<void>;
  getAccessToken: () => Promise<string>;
}

/**
 * Auth context provider props
 */
export interface AuthContextProviderProps {
  children: React.ReactNode;
  providerType?: ProviderType;
  providerConfig: ProviderConfig;
  onLogin?: (user: any) => void;
  onLogout?: () => void;
  onError?: (error: Error) => void;
}

/**
 * WithAuth options
 */
export interface WithAuthOptions {
  LoadingComponent?: React.ComponentType;
  UnauthenticatedComponent?: React.ComponentType;
}

/**
 * Auth provider class
 */
export class AuthProvider {
  constructor(config: { providerType?: ProviderType; providerConfig: ProviderConfig });
  initialize(): Promise<AuthProvider>;
  login(options?: any): Promise<boolean>;
  loginWithPopup(options?: any): Promise<any>;
  logout(options?: any): Promise<boolean>;
  getAccessToken(): Promise<string>;
  isAuthenticated(): Promise<boolean>;
  getUserProfile(): Promise<any>;
  on(event: string, callback: (data: any) => void): void;
  off(event: string, callback: (data: any) => void): void;
}

/**
 * Auth0 provider class
 */
export class Auth0Provider {
  constructor(config: ProviderConfig);
  initialize(): Promise<Auth0Provider>;
  login(options?: any): Promise<boolean>;
  loginWithPopup(options?: any): Promise<any>;
  logout(options?: any): Promise<boolean>;
  getAccessToken(): Promise<string>;
  isAuthenticated(): Promise<boolean>;
  getUserProfile(): Promise<any>;
  onEvent(callback: (event: string, data: any) => void): void;
}

/**
 * Auth context provider component
 */
export const AuthContextProvider: React.FC<AuthContextProviderProps>;

/**
 * Hook to use auth context
 */
export function useAuth(): AuthContextValue;

/**
 * HOC to wrap components with auth
 */
export function withAuth<P extends object>(
  Component: React.ComponentType<P & { auth: AuthContextValue }>,
  options?: WithAuthOptions
): React.FC<P>;